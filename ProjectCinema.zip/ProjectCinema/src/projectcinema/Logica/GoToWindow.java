/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectcinema.Logica;

import projectcinema.SelectMovie;

/**
 *
 * @author robertramirez
 */
public class GoToWindow {
    
    
    
    public void GoToBill(){
    
    
    }
    public void GoToSelectMovie(){
        SelectMovie goback = new SelectMovie();
        goback.setVisible(true);
    
    }
    public void GoToTicketsMenu(){
    
    
    }
    
}
